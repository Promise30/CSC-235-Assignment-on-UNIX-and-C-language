#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char str[200], reversedString[200];

    printf("Enter a string: ");
    gets(str);

    // Find the length of the sentence
    int length = strlen(str);

    printf("Reversed Sentence: \n");
    for(int i = length-1; i>=0; i--){
        printf("%c", str[i]);
    }

    return 0;
}
