#include <stdio.h>
#include <stdlib.h>

int main()
{
    // C Program to say Hello World to your Lecturer.
    char name[50];
    printf("Kindly enter your name: ");
    fgets(name, 50, stdin);
    printf("Welcome %s\nHello world!\n",name);
    return 0;
}
