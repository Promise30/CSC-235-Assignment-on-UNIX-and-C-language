#include <stdio.h>
#include <stdlib.h>
int main()
{
    // C PROGRAM TO ACCEPT THE NAMES OF 10 STUDENTS

    int numStudents = 10;
    char students[numStudents][50];
    for(int i= 0; i < 10; ++i){
        printf("Enter your name: ");
        gets(students[i]);

    }
    printf("STUDENTS NAMES: \n");
    int index = 1;
    for(int j = 0; j < 10; ++j){
        printf("%d. %s\n",index, students[j]);
        index++;
    }
    return 0;
}
