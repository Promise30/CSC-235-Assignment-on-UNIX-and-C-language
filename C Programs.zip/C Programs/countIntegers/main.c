#include <stdio.h>
#include <stdlib.h>

int main()
{
    // C Proogram to count 1-N
    int number;

    printf("Enter any positive integer value: ");

    scanf("%d", &number);

    printf("Numbers from 1 to %d:\n", number);
    for(int i=1; i<=number; i++){
        printf("%d\n", i);
    }
    return 0;
}
