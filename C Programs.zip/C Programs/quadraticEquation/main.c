#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    // C Program to Solve a Simple Quadratic Equation (x2+y+c=0)
    double a,b,c, discriminant, root1, root2, realPart, imaginaryPart;
    printf("Enter the coefficient of X2: ");
    scanf("%lf", &a);

    printf("Enter the value of the coefficient of X: ");
    scanf("%lf", &b);

    printf("Enter the value of the coefficient of the constant: ");
    scanf("%lf", &c);

    printf("X2: %f\n  X: %f\n C: %f\n", a, b, c);

    discriminant = b*b - (4*a*c);
    //printf("Value of discriminant: %.2lf\n", discriminant);

    if(discriminant > 0){
        root1 = (-b + sqrt(discriminant)) / (2*a);
        root2 = (-b - sqrt(discriminant)) / (2*a);
        printf("Root1: %.2lf \nRoot2: %.2lf\n", root1, root2);
    }
    else if(discriminant == 0){
        root1 = root2 = -b / (2*a);
        printf("Root1 = Root2: %.2lf \n", root1);
    }
    else{
        realPart = -b / (2*a);
        imaginaryPart = sqrt(-discriminant) / (2*a);
        printf("Root1: %.2lf + %.2lf \nRoot2: %.2lf - %.2lf", realPart, imaginaryPart, realPart, imaginaryPart);
    }
    return 0;
}
